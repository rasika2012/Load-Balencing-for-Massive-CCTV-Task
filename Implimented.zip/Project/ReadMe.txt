Run Server first 
./server [port] should be 4097
./midleware --> camera port is 4097
		server port is 5000 default
	> Read from camera add to Q1
	> process and add to Q 2
	> Serve from Q2

./client [5000]
